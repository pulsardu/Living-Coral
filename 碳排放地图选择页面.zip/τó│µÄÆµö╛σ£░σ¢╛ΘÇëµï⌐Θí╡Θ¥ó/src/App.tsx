function App() {
  return (
    <div style={{
      padding: '20px',
      fontFamily: 'system-ui, sans-serif',
      backgroundColor: 'white',
      minHeight: '100vh'
    }}>
      <h1 style={{
        textAlign: 'center',
        fontSize: '24px',
        marginBottom: '30px',
        color: '#333'
      }}>
        Transportation Planning
      </h1>
      
      <div style={{
        maxWidth: '400px',
        margin: '0 auto'
      }}>
        <div style={{
          height: '150px',
          backgroundColor: '#f0fdf4',
          border: '2px solid #bbf7d0',
          borderRadius: '12px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: '20px'
        }}>
          <span style={{ fontSize: '20px' }}>🗺️ UQ Lake → Brisbane City Hall</span>
        </div>
        
        <div style={{ marginBottom: '20px' }}>
          <h2 style={{ fontSize: '18px', marginBottom: '10px' }}>Transportation Modes</h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '10px'
          }}>
            <div style={{
              padding: '10px',
              border: '2px solid #22c55e',
              borderRadius: '8px',
              backgroundColor: '#f0fdf4',
              textAlign: 'center'
            }}>
              <div>🚶 Walking</div>
              <div style={{ fontSize: '12px', color: '#22c55e' }}>0g CO₂</div>
            </div>
            
            <div style={{
              padding: '10px',
              border: '1px solid #ddd',
              borderRadius: '8px',
              backgroundColor: 'white',
              textAlign: 'center'
            }}>
              <div>🚴 Cycling</div>
              <div style={{ fontSize: '12px', color: '#666' }}>15g CO₂</div>
            </div>
            
            <div style={{
              padding: '10px',
              border: '1px solid #ddd',
              borderRadius: '8px',
              backgroundColor: 'white',
              textAlign: 'center'
            }}>
              <div>🚌 Bus</div>
              <div style={{ fontSize: '12px', color: '#666' }}>120g CO₂</div>
            </div>
            
            <div style={{
              padding: '10px',
              border: '1px solid #ddd',
              borderRadius: '8px',
              backgroundColor: 'white',
              textAlign: 'center'
            }}>
              <div>🚇 Train</div>
              <div style={{ fontSize: '12px', color: '#666' }}>85g CO₂</div>
            </div>
          </div>
        </div>
        
        <div style={{ marginBottom: '20px' }}>
          <h2 style={{ fontSize: '18px', marginBottom: '10px' }}>Walking Routes</h2>
          
          <div style={{
            padding: '12px',
            border: '2px solid #22c55e',
            borderRadius: '8px',
            backgroundColor: '#f0fdf4',
            marginBottom: '8px'
          }}>
            <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>Recommended Route ⭐</div>
            <div style={{ fontSize: '14px', display: 'flex', justifyContent: 'space-between' }}>
              <span>⏱️ 45 min</span>
              <span>📍 3.2 km</span>
              <span style={{ color: '#22c55e' }}>🌱 0g CO₂</span>
            </div>
          </div>
          
          <div style={{
            padding: '12px',
            border: '1px solid #ddd',
            borderRadius: '8px',
            backgroundColor: 'white'
          }}>
            <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>Shortest Route</div>
            <div style={{ fontSize: '14px', display: 'flex', justifyContent: 'space-between' }}>
              <span>⏱️ 38 min</span>
              <span>📍 2.8 km</span>
              <span>🌱 0g CO₂</span>
            </div>
          </div>
        </div>
        
        <div style={{
          padding: '12px',
          backgroundColor: '#f0fdf4',
          border: '2px solid #bbf7d0',
          borderRadius: '8px',
          textAlign: 'center'
        }}>
          <div style={{ fontWeight: 'bold', color: '#059669', marginBottom: '4px' }}>
            🌍 Eco-Friendly Travel
          </div>
          <div style={{ fontSize: '14px', color: '#047857' }}>
            Choose low-carbon travel to protect our planet!
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
// Simplified component
export function RouteList() {
  return <div>Routes</div>;
}
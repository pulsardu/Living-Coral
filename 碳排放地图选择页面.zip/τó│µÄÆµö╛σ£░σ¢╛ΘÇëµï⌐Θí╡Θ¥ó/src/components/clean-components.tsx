// Clean simplified components to replace complex UI components

// Button
export function Button({ children, className, ...props }: any) {
  return (
    <button 
      className={className}
      style={{ 
        padding: '8px 16px', 
        border: '1px solid #ccc', 
        borderRadius: '4px',
        backgroundColor: 'white',
        cursor: 'pointer'
      }}
      {...props}
    >
      {children}
    </button>
  );
}

// Badge
export function Badge({ children, className, ...props }: any) {
  return (
    <span 
      className={className}
      style={{
        display: 'inline-block',
        padding: '2px 8px',
        fontSize: '12px',
        borderRadius: '12px',
        backgroundColor: '#f3f4f6',
        color: '#374151'
      }}
      {...props}
    >
      {children}
    </span>
  );
}

// Card
export function Card({ children, className, ...props }: any) {
  return (
    <div 
      className={className}
      style={{
        border: '1px solid #e5e7eb',
        borderRadius: '8px',
        backgroundColor: 'white'
      }}
      {...props}
    >
      {children}
    </div>
  );
}

// Utils function
export function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
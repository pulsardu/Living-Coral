// Simplified button component
export function Button({ children, ...props }: any) {
  return <button {...props}>{children}</button>;
}
// Simplified alert component
export function Alert({ children, ...props }: any) {
  return <div {...props}>{children}</div>;
}
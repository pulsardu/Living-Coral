// Simplified accordion component
export function Accordion({ children, ...props }: any) {
  return <div {...props}>{children}</div>;
}

export function AccordionItem({ children, ...props }: any) {
  return <div {...props}>{children}</div>;
}

export function AccordionTrigger({ children, ...props }: any) {
  return <button {...props}>{children}</button>;
}

export function AccordionContent({ children, ...props }: any) {
  return <div {...props}>{children}</div>;
}
// Simplified utils
export function cn(...args: any[]) {
  return args.filter(Boolean).join(' ');
}
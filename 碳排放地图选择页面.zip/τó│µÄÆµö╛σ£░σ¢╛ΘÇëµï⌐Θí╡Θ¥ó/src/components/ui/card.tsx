// Simplified card component
export function Card({ children, ...props }: any) {
  return <div {...props}>{children}</div>;
}
// Simplified mobile hook
export function useIsMobile() {
  return false;
}
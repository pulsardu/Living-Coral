// Simplified alert dialog component
export function AlertDialog({ children, ...props }: any) {
  return <div {...props}>{children}</div>;
}
// Simplified badge component
export function Badge({ children, ...props }: any) {
  return <span {...props}>{children}</span>;
}
// Empty placeholder file to prevent build issues
export default function EmptyPlaceholder() {
  return null;
}
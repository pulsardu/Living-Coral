// Simplified component
export function MapView() {
  return <div>Map</div>;
}
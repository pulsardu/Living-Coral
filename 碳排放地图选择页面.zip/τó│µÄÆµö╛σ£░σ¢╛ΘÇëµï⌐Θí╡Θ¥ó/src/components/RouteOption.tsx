// Simplified component
export function RouteOption() {
  return <div>Route</div>;
}
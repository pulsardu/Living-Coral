// Simplified component
export function TransportModeSelector() {
  return <div>Transport</div>;
}
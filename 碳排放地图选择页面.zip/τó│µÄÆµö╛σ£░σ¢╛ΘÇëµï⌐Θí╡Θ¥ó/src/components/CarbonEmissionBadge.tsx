// Simplified component
export function CarbonEmissionBadge() {
  return <span>Badge</span>;
}
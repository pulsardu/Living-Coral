
  # 碳排放地图选择页面

  This is a code bundle for 碳排放地图选择页面. The original project is available at https://www.figma.com/design/hqelAYmK1cShLWAmolafzP/%E7%A2%B3%E6%8E%92%E6%94%BE%E5%9C%B0%E5%9B%BE%E9%80%89%E6%8B%A9%E9%A1%B5%E9%9D%A2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  